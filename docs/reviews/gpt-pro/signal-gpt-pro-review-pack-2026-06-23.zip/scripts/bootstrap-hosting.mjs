import { spawnSync } from "child_process";
import { existsSync } from "fs";

const apply = process.env.DEPLOY_APPLY === "1";
const supabaseToken = process.env.SUPABASE_ACCESS_TOKEN;
const supabaseProjectRef = process.env.SUPABASE_PROJECT_REF;
const supabaseDbPassword = process.env.SUPABASE_DB_PASSWORD;
const vercelToken = process.env.VERCEL_TOKEN;
const vercelProject = process.env.VERCEL_PROJECT_ID || process.env.VERCEL_PROJECT_NAME;
const vercelTeam = process.env.VERCEL_TEAM_ID || process.env.VERCEL_TEAM_SLUG;
const vercelLinkedProject = existsSync(".vercel/project.json");

const steps = [];

step("Local verification", "npm", ["run", "verify"]);
step("Local Supabase verification", "npm", ["run", "verify:db"]);

if (supabaseToken) {
  step("Supabase login", "supabase", ["login", "--token", supabaseToken, "--name", "signal-deploy"]);
} else {
  note("SUPABASE_ACCESS_TOKEN is missing; hosted Supabase login skipped.");
}

if (supabaseToken && supabaseProjectRef) {
  const linkArgs = ["link", "--project-ref", supabaseProjectRef];
  if (supabaseDbPassword) linkArgs.push("--password", supabaseDbPassword);
  step("Supabase link", "supabase", linkArgs);
  const pushArgs = ["db", "push", "--linked"];
  if (supabaseDbPassword) pushArgs.push("--password", supabaseDbPassword);
  if (!apply) pushArgs.push("--dry-run");
  step(apply ? "Supabase db push" : "Supabase db push dry-run", "supabase", pushArgs);
  step("Supabase migration list", "supabase", ["migration", "list"]);
  if (vercelToken || vercelProject || vercelLinkedProject) {
    step("Vercel Supabase env sync", "npm", ["run", "deploy:sync-supabase-env"]);
  } else {
    note("Vercel project is not linked; Supabase env sync skipped.");
  }
} else if (supabaseToken) {
  note("SUPABASE_PROJECT_REF is missing; hosted Supabase link skipped.");
}

if (vercelToken) {
  step("Vercel whoami", "npx", ["--yes", "vercel", "whoami", "--token", vercelToken]);
  if (vercelProject) {
    const linkArgs = ["--yes", "vercel", "link", "--yes", "--project", vercelProject, "--token", vercelToken];
    if (vercelTeam) linkArgs.splice(linkArgs.length - 2, 0, "--team", vercelTeam);
    step("Vercel link", "npx", linkArgs);
    if (apply) {
      const deployArgs = ["--yes", "vercel", "deploy", "--prod", "--yes", "--token", vercelToken];
      if (vercelTeam) deployArgs.splice(deployArgs.length - 2, 0, "--scope", vercelTeam);
      step("Vercel production deploy", "npx", deployArgs);
    } else {
      note("DEPLOY_APPLY is not 1; Vercel deploy skipped.");
    }
  } else {
    note("VERCEL_PROJECT_ID or VERCEL_PROJECT_NAME is missing; Vercel link skipped.");
  }
} else {
  note("VERCEL_TOKEN is missing; Vercel login/link/deploy skipped.");
}

console.log("\nBootstrap summary");
for (const item of steps) {
  console.log(`${item.ok ? "OK " : "NO "} ${item.name}${item.detail ? ` - ${item.detail}` : ""}`);
}

const failed = steps.filter((item) => !item.ok);
if (failed.length > 0) process.exit(1);

function step(name, command, args) {
  const env = { ...process.env, SUPABASE_TELEMETRY_DISABLED: "1" };
  const maskedArgs = args.map(mask);
  console.log(`\n> ${command} ${maskedArgs.join(" ")}`);
  const result = spawnSync(command, args, {
    cwd: process.cwd(),
    env,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
  });
  const output = [result.stdout, result.stderr].filter(Boolean).join("\n").trim();
  if (output) console.log(mask(output));
  steps.push({
    name,
    ok: result.status === 0,
    detail: result.status === 0 ? "" : firstLine(output),
  });
}

function note(message) {
  console.log(`\n- ${message}`);
  steps.push({ name: message, ok: true });
}

function firstLine(value) {
  return value.split(/\r?\n/).find(Boolean) ?? "no output";
}

function mask(value) {
  let masked = String(value);
  for (const secret of [supabaseToken, supabaseDbPassword, vercelToken]) {
    if (secret) masked = masked.split(secret).join("<redacted>");
  }
  return masked;
}
